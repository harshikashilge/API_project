package ProductCategoryProject.ProductCategoryProject;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Category {

	@Id
	private int categoryid;
	private String category;
	@OneToMany(targetEntity = Product.class, cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "categoryid")
	List<Product> products;

	public Category() {
		super();
	}

	public Category(int categoryid, String category, List<Product> products) {
		super();
		this.categoryid = categoryid;
		this.category = category;
		this.products = products;
	}

	public int getCategoryid() {
		return categoryid;
	}

	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "Category [categoryid=" + categoryid + ", category=" + category + ", products=" + products + "]";
	}

}
