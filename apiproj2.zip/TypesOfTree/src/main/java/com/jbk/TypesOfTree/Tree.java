package com.jbk.TypesOfTree;

public class Tree {
	
	int treeid;
	String treename;
	String treeheight;
	String treewidth;
	
	public Tree(int treeid, String treename, String treeheight, String treewidth) {
		super();
		this.treeid = treeid;
		this.treename = treename;
		this.treeheight = treeheight;
		this.treewidth = treewidth;
	}
	
	public int getTreeno() {
		return treeid;
	}

	public void setTreeno(int treeno) {
		this.treeid = treeid;
	}

	public String getTreename() {
		return treename;
	}

	public void setTreename(String treename) {
		this.treename = treename;
	}

	public String getTreeheight() {
		return treeheight;
	}

	public void setTreeheight(String treeheight) {
		this.treeheight = treeheight;
	}

	public String getTreewidth() {
		return treewidth;
	}

	public void setTreewidth(String treewidth) {
		this.treewidth = treewidth;
	}

	@Override
	public String toString() {
		return "Tree [treeid=" + treeid + ", treename=" + treename + ", treeheight=" + treeheight + ", treewidth="
				+ treewidth + "]";
	}
	
	

}
