package com.jbk.TypesOfTree;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

@Component
public class TreeTypeDao {

		public  ArrayList<Tree> fetchtreeinfo()
		{
			ArrayList<Tree> al = new ArrayList<Tree>();
			
			try {
			
			System.out.println(1);
			Class.forName("com.mysql.jdbc.Driver");
			
			System.out.println(2);
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
			
			System.out.println(3);
			String sql="select * from tree";
			
			System.out.println(4);
			 Statement statement = connection.createStatement();
			 
			 System.out.println(5);
			 ResultSet resultset= statement.executeQuery(sql);
			 
			 while(resultset.next())
			 {
				int treeid = resultset.getInt(1);
				String treename = resultset.getString(2);
				String treeheight = resultset.getString(3);
				String treewidth = resultset.getString(4);
				
				Tree tree = new Tree(treeid, treename, treeheight, treewidth);
				al.add(tree);
			 }
			 System.err.println("I am in Dao...");
		}catch(Exception e)
		{
			e.printStackTrace();
		}	
			 
			 return al;
		}

	

}
