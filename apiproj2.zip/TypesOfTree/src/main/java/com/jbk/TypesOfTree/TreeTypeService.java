package com.jbk.TypesOfTree;

import java.util.ArrayList;

import org.springframework.stereotype.Component;

@Component
public class TreeTypeService {

		public ArrayList<Tree> fetchtreeinfo()
		{
			ArrayList<Tree> tr= new ArrayList<Tree>();
			
			Tree tree= new Tree(001,"Apple tree", "20mtr", "10mtr");
			Tree tree1= new Tree(002,"Orange tree", "30mtr","15mtr");
			Tree tree2= new Tree(003,"banana tree" ,"40mtr","1mtr");
			Tree tree3= new Tree(004,"kiwi tree","10mtr","2mtr");
			
			tr.add(tree);
			tr.add(tree1);
			tr.add(tree2);
			tr.add(tree3);
			
			System.err.println("im in service block");
			
			return tr;
		}
	
}
