package com.jbk.TypesOfTree;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class TreetypeController {
	@Autowired
	TreeTypeService treetypeservice = null;
	
	@RequestMapping("treeinfo")
	ArrayList<Tree> fetchtreeinfo()
	{
		//TreeTypeService treetypeservice = new TreeTypeService();
		ArrayList<Tree> str= treetypeservice.fetchtreeinfo();
		
		System.err.println("im in controller");
		return str;
	}
}
