package com.jbk.TypesOfTree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TypesOfTreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
